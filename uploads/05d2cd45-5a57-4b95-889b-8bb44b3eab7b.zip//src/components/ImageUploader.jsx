import React, { useState, useEffect } from "react";

function ImageUploader() {
  const [frontFile, setFrontFile] = useState(null);
  const [backFile, setBackFile] = useState(null);
  const [balance, setBalance] = useState("");
  const [balanceResult, setBalanceResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isUploaded, setIsUploaded] = useState(false);
  const [selectedImage, setSelectedImage] = useState(
    "https://pbs.twimg.com/media/EQ2uD4cWsAAJrhk.jpg"
  );
  const [selectedButton, setSelectedButton] = useState("");
  const [showCardPopup, setShowCardPopup] = useState(false);
  const [step, setStep] = useState(1);
  const [savedCards, setSavedCards] = useState([]);
  const [showSavedCards, setShowSavedCards] = useState(false); // Track visibility of saved cards popup

  useEffect(() => {
    if (frontFile && step === 2) {
      setIsUploaded(true);
    }
  }, [frontFile, step]);

  const handlePrevClick = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? 3 : prevIndex - 1));
  };

  const handleNextClick = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 3 ? 0 : prevIndex + 1));
  };

  const handleFrontFileChange = (event) => {
    setFrontFile(event.target.files[0]);
    setStep(2);
  };

  const handleBackFileChange = (event) => {
    setBackFile(event.target.files[0]);
  };

  const handleCheckBalance = () => {
    setIsLoading(true);

    setTimeout(() => {
      let status;
      let amount = "$0";
      const now = new Date().toLocaleString();

      if (balance === "1234") {
        status = "Valid";
        amount = "$100";
        setBalanceResult("Your balance is $100");
      } else {
        status = "Invalid";
        setBalanceResult("Enter a valid number");
      }

      setSavedCards([
        ...savedCards,
        {
          picture: URL.createObjectURL(frontFile),
          cardNumber: balance,
          status: status,
          amountChecked: amount,
          dateChecked: now,
        },
      ]);

      setIsLoading(false);
    }, 2000);
  };

  const handleSavedCardsClick = () => {
    setShowSavedCards(!showSavedCards); // Toggle visibility of saved cards popup
  };

  const handleImageSelection = (imageUrl, buttonId) => {
    setSelectedImage(imageUrl);
    setSelectedButton(buttonId);
  };

  const handleOtherCardsClick = () => {
    setFrontFile(null);
    setBackFile(null);
    setIsUploaded(false);
    setBalance("");
    setBalanceResult(null);
    setSelectedImage("https://pbs.twimg.com/media/EQ2uD4cWsAAJrhk.jpg");
    setSelectedButton("");
    setStep(1);
  };

  const handleMoreCardsClick = () => {
    setShowCardPopup(true);
  };

  const handleCardSelection = (imageUrl, buttonId) => {
    handleImageSelection(imageUrl, buttonId);
    setShowCardPopup(false);
  };

  return (
    <div className="container">
      {step === 1 ? (
        <>
          <div className="header">
            <h2 className="payment-text">Verify Your Apple Gift Card</h2>
          </div>

          <div className="payment-options">{/* Payment buttons */}</div>

          <div className="more-cards-container">
            <button
              className="more-cards-button"
              onClick={handleSavedCardsClick} // Toggle saved cards popup
            >
              Saved Cards
            </button>
          </div>

          <input
            type="file"
            onChange={handleFrontFileChange}
            placeholder="Upload front gift card"
          />
          {frontFile && (
            <div className="image-container">
              <img
                src={URL.createObjectURL(frontFile)}
                alt="Front Uploaded"
                className="uploaded-image"
              />
              <div className="verification-message">
                Front image uploaded successfully! Please upload the back card.
              </div>
            </div>
          )}

          {step === 2 && !backFile && (
            <>
              <input
                type="file"
                onChange={handleBackFileChange}
                placeholder="Upload back gift card"
              />
              {backFile && (
                <div className="image-container">
                  <img
                    src={URL.createObjectURL(backFile)}
                    alt="Back Uploaded"
                    className="uploaded-image"
                  />
                  <div className="verification-message">
                    Back image uploaded successfully!
                  </div>
                </div>
              )}
            </>
          )}
        </>
      ) : (
        <div className="apple-cards-container">
          <h2>CHECK YOUR CARD BALANCE</h2>
          <div className="slider">
            <div
              className="slider-track"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {[...Array(4)].map((_, index) => (
                <img
                  key={index}
                  src={selectedImage}
                  alt={`Slide ${index + 1}`}
                />
              ))}
            </div>
            <div className="slider-controls">
              <button className="slider-control" onClick={handlePrevClick}>
                ❮
              </button>
              <button className="slider-control" onClick={handleNextClick}>
                ❯
              </button>
            </div>
          </div>

          <div className="balance-check">
            <input
              type="text"
              className="balance-input"
              placeholder="Enter your gift card number"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
            />
            <button
              className="check-balance-button"
              onClick={handleCheckBalance}
            >
              Check Balance
            </button>
          </div>

          {isLoading ? (
            <div className="rolling-message">
              <div className="spinner"></div>
              <div className="rolling-text">Checking balance...</div>
            </div>
          ) : (
            balanceResult && (
              <div
                className={`balance-result ${
                  balanceResult === "Enter a valid number" ? "danger" : ""
                }`}
              >
                {balanceResult}
              </div>
            )
          )}

          <button
            className="other-cards-button"
            onClick={handleOtherCardsClick}
          >
            Other Cards
          </button>

          {/* New Text */}
          <div className="gift-card-info">
            Your gift card balance never expires and is non-transferable after
            its first use
          </div>
        </div>
      )}

      {/* Popup for More Cards */}
      {showCardPopup && (
        <div className="card-popup">
          <div className="card-popup-content">
            <h2>Select a Card</h2>
            <div className="card-options">{/* Card options */}</div>

            <button
              className="close-popup-button"
              onClick={() => setShowCardPopup(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Saved Cards Popup */}
      {showSavedCards && (
        <div className="saved-cards-popup">
          <div className="saved-cards-content">
            <h2>Saved Cards</h2>
            <button
              className="close-popup-button"
              onClick={handleSavedCardsClick}
            >
              Close
            </button>
            <div className="saved-cards-container">
              <table className="saved-cards-table">
                <thead>
                  <tr>
                    <th>Picture</th>
                    <th>Card Number</th>
                    <th>Status</th>
                    <th>Amount Checked (Date)</th>
                  </tr>
                </thead>
                <tbody>
                  {savedCards.map((card, index) => (
                    <tr key={index}>
                      <td>
                        <img
                          src={card.picture}
                          alt={`Card ${index + 1}`}
                          className="saved-card-image"
                        />
                      </td>
                      <td>{card.cardNumber}</td>
                      <td>{card.status}</td>
                      <td>{`${card.amountChecked} (${card.dateChecked})`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ImageUploader;
