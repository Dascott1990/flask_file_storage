import React from "react";

function Header() {
  return (
    <header>
      <img src="/images/Apple.png" alt="Apple Logo" className="header-logo" />
    </header>
  );
}

export default Header;
